interface Window {
  TradingView: {
    widget: new (config: any) => any;
  };
}