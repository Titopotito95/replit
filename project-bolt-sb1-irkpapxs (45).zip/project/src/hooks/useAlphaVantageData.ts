import { useEffect, useState, useRef } from 'react';

interface CandleData {
  time: number;
  open: number;
  high: number;
  low: number;
  close: number;
}

export function useAlphaVantageData(symbol: string = 'EUR/USD') {
  const [data, setData] = useState<CandleData[]>([]);
  const [isConnected, setIsConnected] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const lastUpdateRef = useRef<number>(Date.now());
  const lastCloseRef = useRef<number | null>(null);

  // Generate initial mock data
  const generateMockData = () => {
    const mockData: CandleData[] = [];
    const now = Math.floor(Date.now() / 1000);
    
    // Base prices for different currency pairs
    const basePrices: Record<string, number> = {
      'EUR/USD': 1.1000,
      'GBP/USD': 1.2500,
      'USD/JPY': 110.00,
      'USD/CHF': 0.9200,
      'AUD/USD': 0.7500,
      'USD/CAD': 1.3000,
      'NZD/USD': 0.7000,
      'EUR/GBP': 0.8800,
      'EUR/JPY': 120.00,
      'GBP/JPY': 140.00
    };
    
    const basePrice = basePrices[symbol] || 1.1000;
    let lastClose = basePrice;
    
    // Generate historical candles
    for (let i = 0; i < 100; i++) {
      const time = now - (100 - i) * 60;
      const volatility = 0.0002; // Reduced volatility for more realistic forex movements
      const trend = Math.sin(i / 10) * 0.0001;
      const randomChange = (Math.random() - 0.5) * volatility + trend;
      
      const open = lastClose;
      const close = Number((open * (1 + randomChange)).toFixed(5));
      const high = Number((Math.max(open, close) * (1 + Math.random() * 0.0001)).toFixed(5));
      const low = Number((Math.min(open, close) * (1 - Math.random() * 0.0001)).toFixed(5));
      
      mockData.push({
        time,
        open,
        high,
        low,
        close
      });
      
      lastClose = close;
    }
    
    lastCloseRef.current = lastClose;
    return mockData;
  };

  // Initialize data on symbol change
  useEffect(() => {
    const mockData = generateMockData();
    setData(mockData);
    setIsConnected(true);
    lastUpdateRef.current = Date.now();
  }, [symbol]);

  // Real-time updates
  useEffect(() => {
    if (!isConnected || data.length === 0) return;

    const updateInterval = setInterval(() => {
      const now = Date.now();
      const timeSinceLastUpdate = now - lastUpdateRef.current;
      
      // Ensure we have a last close price
      if (lastCloseRef.current === null) {
        lastCloseRef.current = data[data.length - 1].close;
      }

      // Create new candle every minute
      const shouldCreateNewCandle = timeSinceLastUpdate >= 60000;
      
      // Generate new price data
      const volatility = 0.0002;
      const trend = Math.sin(now / 10000) * 0.0001;
      const randomChange = (Math.random() - 0.5) * volatility + trend;
      
      const lastPrice = lastCloseRef.current;
      const newPrice = Number((lastPrice * (1 + randomChange)).toFixed(5));
      
      setData(prevData => {
        const lastCandle = prevData[prevData.length - 1];
        
        if (shouldCreateNewCandle) {
          // Create new candle
          const newCandle: CandleData = {
            time: Math.floor(now / 1000),
            open: lastPrice,
            high: Math.max(lastPrice, newPrice),
            low: Math.min(lastPrice, newPrice),
            close: newPrice
          };
          
          lastUpdateRef.current = now;
          lastCloseRef.current = newPrice;
          
          return [...prevData.slice(-999), newCandle];
        } else {
          // Update last candle
          const updatedCandle: CandleData = {
            ...lastCandle,
            high: Math.max(lastCandle.high, newPrice),
            low: Math.min(lastCandle.low, newPrice),
            close: newPrice
          };
          
          lastCloseRef.current = newPrice;
          
          return [...prevData.slice(0, -1), updatedCandle];
        }
      });
    }, 1000); // Update every second for smoother price movement

    return () => clearInterval(updateInterval);
  }, [isConnected, data, symbol]);

  return { data, isConnected, error };
}